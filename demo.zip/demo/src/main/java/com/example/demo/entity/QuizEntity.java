package com.example.demo.entity;

import com.example.demo.dto.QuizDto;
import jdk.internal.jline.internal.Nullable;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Data
public class QuizEntity {
    @Id
    @GeneratedValue
    @Column(name = "id", nullable = false)
    @Nullable
    private long id;

    @Column(name = "name", nullable = false, unique = true)
    private String name;

    @Column(name = "start_date", nullable = false)
    private Date startDate;

    @Column(name = "finish_date", nullable = false)
    private Date finishDate;

    @Column(name = "status", nullable = false)
    private String status;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "link_quiz")
    private List<QuestionEntity> questionEntities;

    public QuizEntity toQuizEntity(QuizDto quizDto) {
        QuizEntity quizEntity = new QuizEntity();
        quizEntity.setName(quizDto.getName());
        quizEntity.setFinishDate(quizDto.getFinishDate());
        quizEntity.setStartDate(quizDto.getStartDate());
        quizEntity.setStatus(quizDto.getStatus());
        return quizEntity;
    }

}
