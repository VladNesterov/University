package com.example.demo.dto;

import lombok.Data;

@Data
public class QuestionResponseDto {

    String nameQuiz;
    String text;
    int order;

}
