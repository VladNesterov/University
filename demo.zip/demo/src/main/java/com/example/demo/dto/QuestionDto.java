package com.example.demo.dto;

import lombok.Data;

@Data
public class QuestionDto {

    String nameQuiz;
    String text;
    long order;

}
